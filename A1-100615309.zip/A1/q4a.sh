#!/bin/bash

#

#QUESTION 4a
echo "QUESTION 4a -"
printf "Number of lines across both files:\n"
wc -l ATaleofTwoCities.txt AliceInWonderland.txt
# wc is word count -l checks number of lines